import Image from 'next/image';

export default function DJs() {
  const djs = [
    {
      name: 'DJ Cipher',
      style: 'Hip-Hop / Trap',
      image: '/hero.jpeg',
    },
    {
      name: 'DJ Nexus',
      style: 'House / EDM',
      image: '/hero.jpeg',
    },
    {
      name: 'DJ Phantom',
      style: 'R&B / Soul',
      image: '/hero.jpeg',
    },
    {
      name: 'DJ Vortex',
      style: 'Techno / DnB',
      image: '/hero.jpeg',
    },
  ];
  return (
    <div className="djs-page">
      <h1>Our DJs</h1>
      <p className="intro">Meet the artists behind the beats.</p>
      <div className="grid">
        {djs.map((dj) => (
          <div key={dj.name} className="card">
            <div className="image-wrapper">
              <Image
                src={dj.image}
                alt={dj.name}
                layout="fill"
                objectFit="cover"
              />
            </div>
            <h3>{dj.name}</h3>
            <p className="style">{dj.style}</p>
          </div>
        ))}
      </div>
      <style jsx>{`
        h1 {
          text-align: center;
          margin-bottom: 0.5rem;
          font-size: 2rem;
        }
        .intro {
          text-align: center;
          margin-bottom: 2rem;
          color: #ccc;
        }
        .grid {
          display: grid;
          gap: 2rem;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        }
        .card {
          background: #111;
          padding: 1rem;
          border-radius: 8px;
          text-align: center;
          border: 1px solid #222;
        }
        .image-wrapper {
          position: relative;
          width: 100%;
          height: 180px;
          margin-bottom: 1rem;
          overflow: hidden;
          border-radius: 4px;
        }
        h3 {
          margin: 0 0 0.25rem;
          font-size: 1.2rem;
          color: #d4af37;
        }
        .style {
          margin: 0;
          font-size: 0.9rem;
          color: #aaa;
        }
      `}</style>
    </div>
  );
}