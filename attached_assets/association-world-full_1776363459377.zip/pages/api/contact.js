import nodemailer from 'nodemailer';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ error: 'Method Not Allowed' });
  }
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  try {
    // Configure transporter using environment variables. Provide your own SMTP credentials here.
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '465', 10),
      secure: true,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
    await transporter.sendMail({
      from:
        process.env.FROM_EMAIL
          ? `Association World <${process.env.FROM_EMAIL}>`
          : 'Association World <management@associationworld.com>',
      to:
        process.env.CONTACT_TO ||
        process.env.MANAGEMENT_EMAIL ||
        'management@associationworld.com',
      replyTo: email,
      subject: `New contact form submission from ${name}`,
      text: `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`,
    });
    return res.status(200).json({ success: true });
  } catch (error) {
    console.error('Error sending contact form email:', error);
    return res.status(500).json({ error: 'Unable to send email' });
  }
}