import { useState } from 'react';

export default function Booking() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    eventType: '',
    eventDate: '',
    location: '',
    artist: '',
    budget: '',
    message: '',
  });
  const [status, setStatus] = useState(null);
  const artists = [
    'DJ Cipher',
    'DJ Nexus',
    'DJ Phantom',
    'DJ Vortex',
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('loading');
    try {
      const res = await fetch('/api/booking', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok) {
        setStatus('success');
        setForm({
          name: '',
          email: '',
          phone: '',
          eventType: '',
          eventDate: '',
          location: '',
          artist: '',
          budget: '',
          message: '',
        });
      } else {
        setStatus(data.error || 'error');
      }
    } catch (err) {
      setStatus('error');
    }
  };

  return (
    <div className="booking-page">
      <h1>Book an Artist</h1>
      <form onSubmit={handleSubmit} className="form">
        <label>
          Full Name
          <input
            type="text"
            name="name"
            value={form.name}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Email
          <input
            type="email"
            name="email"
            value={form.email}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Phone
          <input
            type="tel"
            name="phone"
            value={form.phone}
            onChange={handleChange}
          />
        </label>
        <label>
          Event Type
          <input
            type="text"
            name="eventType"
            value={form.eventType}
            onChange={handleChange}
            placeholder="Wedding, Corporate, Festival..."
            required
          />
        </label>
        <label>
          Event Date
          <input
            type="date"
            name="eventDate"
            value={form.eventDate}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Location
          <input
            type="text"
            name="location"
            value={form.location}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Select Artist / DJ
          <select name="artist" value={form.artist} onChange={handleChange} required>
            <option value="">-- Select --</option>
            {artists.map((artist) => (
              <option key={artist} value={artist}>
                {artist}
              </option>
            ))}
          </select>
        </label>
        <label>
          Budget (USD)
          <input
            type="number"
            name="budget"
            value={form.budget}
            onChange={handleChange}
            placeholder="Estimated budget"
            min="0"
          />
        </label>
        <label>
          Additional Details
          <textarea
            name="message"
            rows="5"
            value={form.message}
            onChange={handleChange}
            placeholder="Tell us more about your event..."
          />
        </label>
        <button type="submit" className="btn btn-primary" disabled={status === 'loading'}>
          {status === 'loading' ? 'Submitting...' : 'Submit Booking'}
        </button>
        {status === 'success' && <p className="success">Your request has been sent. We will contact you shortly.</p>}
        {status && status !== 'success' && status !== 'loading' && (
          <p className="error">Something went wrong. Please try again.</p>
        )}
      </form>
      <style jsx>{`
        h1 {
          margin-bottom: 1.5rem;
          font-size: 2rem;
          text-align: center;
        }
        .form {
          max-width: 700px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }
        label {
          display: flex;
          flex-direction: column;
          font-weight: 500;
        }
        input,
        textarea,
        select {
          margin-top: 0.5rem;
          padding: 0.75rem;
          border: 1px solid #333;
          background: #111;
          color: #fff;
          border-radius: 4px;
        }
        .btn {
          align-self: flex-start;
          border: 1px solid #d4af37;
          padding: 0.75rem 1.5rem;
          background: transparent;
          color: #d4af37;
          font-weight: 600;
          text-transform: uppercase;
          transition: background 0.2s ease, color 0.2s ease;
        }
        .btn:hover:not(:disabled) {
          background: #d4af37;
          color: #000;
        }
        .btn:disabled {
          opacity: 0.5;
        }
        .success {
          margin-top: 1rem;
          color: #4caf50;
        }
        .error {
          margin-top: 1rem;
          color: #f44336;
        }
      `}</style>
    </div>
  );
}