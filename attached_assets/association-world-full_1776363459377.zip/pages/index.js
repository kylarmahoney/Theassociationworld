import Image from 'next/image';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="home-page">
      <div className="hero-section">
        <Image
          src="/hero.jpeg"
          alt="Association World Hero"
          layout="fill"
          objectFit="cover"
          quality={90}
          priority
        />
        <div className="overlay" />
        <div className="hero-content container">
          <h1>
            Loyalty Above All.<br /> Silence is Power.
          </h1>
          <p className="subtext">
            Association World is not a brand. It’s a covenant.
          </p>
          <div className="buttons">
            <Link href="/booking">
              <button className="btn btn-primary">Book an Artist</button>
            </Link>
            <Link href="/merch">
              <button className="btn btn-secondary">Shop Merch</button>
            </Link>
          </div>
        </div>
      </div>
      <style jsx>{`
        .hero-section {
          position: relative;
          height: 80vh;
          width: 100%;
        }
        .overlay {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.6);
        }
        .hero-content {
          position: relative;
          z-index: 2;
          display: flex;
          flex-direction: column;
          justify-content: center;
          height: 100%;
          text-align: center;
          color: #fff;
        }
        .hero-content h1 {
          font-size: 2.5rem;
          line-height: 1.2;
          margin-bottom: 1rem;
        }
        .subtext {
          font-size: 1.1rem;
          margin-bottom: 2rem;
          color: #ccc;
        }
        .buttons {
          display: flex;
          justify-content: center;
          gap: 1rem;
        }
        .btn {
          padding: 0.75rem 1.5rem;
          border: 1px solid #d4af37;
          background: transparent;
          color: #d4af37;
          font-weight: 600;
          text-transform: uppercase;
          transition: background 0.2s ease, color 0.2s ease;
        }
        .btn:hover {
          background: #d4af37;
          color: #000;
        }
        @media (min-width: 768px) {
          .hero-content h1 {
            font-size: 3.5rem;
          }
        }
      `}</style>
    </div>
  );
}