import Image from 'next/image';

export default function Merch() {
  const items = [
    {
      name: 'Gold Emblem Hoodie',
      description: 'Premium black hoodie with gold Association World emblem.',
      price: '$80',
      image: '/logo.jpeg',
    },
    {
      name: 'Signature Tee',
      description: 'Minimalist black tee featuring our gold covenant crest.',
      price: '$45',
      image: '/logo.jpeg',
    },
    {
      name: 'Classic Cap',
      description: 'Black cap with embroidered gold emblem.',
      price: '$35',
      image: '/logo.jpeg',
    },
  ];
  return (
    <div className="merch-page">
      <h1>Merchandise</h1>
      <p className="intro">Premium streetwear inspired by loyalty and secrecy.</p>
      <div className="grid">
        {items.map((item) => (
          <div key={item.name} className="card">
            <div className="image-wrapper">
              <Image
                src={item.image}
                alt={item.name}
                layout="fill"
                objectFit="contain"
              />
            </div>
            <h3>{item.name}</h3>
            <p className="description">{item.description}</p>
            <p className="price">{item.price}</p>
            <button className="btn btn-disabled" disabled>
              Coming Soon
            </button>
          </div>
        ))}
      </div>
      <style jsx>{`
        h1 {
          text-align: center;
          margin-bottom: 0.5rem;
          font-size: 2rem;
        }
        .intro {
          text-align: center;
          margin-bottom: 2rem;
          color: #ccc;
        }
        .grid {
          display: grid;
          gap: 2rem;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        }
        .card {
          background: #111;
          padding: 1.5rem;
          border-radius: 8px;
          text-align: center;
          position: relative;
          border: 1px solid #222;
        }
        .image-wrapper {
          position: relative;
          width: 100%;
          height: 200px;
          margin-bottom: 1rem;
        }
        .card h3 {
          margin: 0 0 0.5rem;
          font-size: 1.2rem;
          color: #d4af37;
        }
        .description {
          font-size: 0.9rem;
          color: #aaa;
          margin-bottom: 0.5rem;
        }
        .price {
          font-weight: 600;
          margin-bottom: 1rem;
        }
        .btn-disabled {
          border: 1px solid #555;
          color: #555;
          padding: 0.75rem 1.5rem;
          background: transparent;
          cursor: not-allowed;
        }
      `}</style>
    </div>
  );
}