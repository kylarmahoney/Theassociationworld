import Link from 'next/link';
import { useRouter } from 'next/router';
import IntroLogo from './IntroLogo';

export default function Layout({ children }) {
  const router = useRouter();
  const navItems = [
    { href: '/', label: 'Home' },
    { href: '/booking', label: 'Booking' },
    { href: '/merch', label: 'Merch' },
    { href: '/djs', label: 'DJs' },
    { href: '/contact', label: 'Contact' },
  ];
  return (
    <div className="layout">
      {/* Display the intro logo overlay on initial load */}
      <IntroLogo />
      <header>
        <nav className="nav-bar container">
          <div className="logo">
            <Link href="/">
              <span>Association <span className="gold">World</span></span>
            </Link>
          </div>
          <ul className="nav-links">
            {navItems.map((item) => (
              <li key={item.href} className={router.pathname === item.href ? 'active' : ''}>
                <Link href={item.href}>{item.label}</Link>
              </li>
            ))}
          </ul>
        </nav>
      </header>
      <main className="main-content container">{children}</main>
      <footer className="footer container">
        <p>© {new Date().getFullYear()} Association World. All rights reserved.</p>
      </footer>
      <style jsx>{`
        .nav-bar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem 0;
          border-bottom: 1px solid #111;
        }
        .logo span {
          font-size: 1.5rem;
          font-weight: 600;
        }
        .nav-links {
          list-style: none;
          display: flex;
          gap: 1.5rem;
          margin: 0;
          padding: 0;
        }
        .nav-links li a {
          color: #fff;
          font-weight: 500;
          transition: color 0.2s ease;
        }
        .nav-links li a:hover,
        .nav-links li.active a {
          color: #d4af37;
        }
        .main-content {
          padding: 2rem 0;
          min-height: calc(100vh - 140px);
        }
        .footer {
          text-align: center;
          padding: 1rem 0;
          border-top: 1px solid #111;
        }
      `}</style>
    </div>
  );
}