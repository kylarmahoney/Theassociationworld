import { useEffect, useState } from 'react';
import Image from 'next/image';

/**
 * IntroLogo component
 *
 * Displays a full‑screen overlay with the Association World logo on initial page
 * load. The overlay fades out after a short delay and then is removed from
 * the DOM. This creates a brief entrance animation when users first arrive on
 * the site. The logo image should have a transparent background for best
 * effect, but any image can be used.
 */
export default function IntroLogo() {
  // Track when the overlay should be completely removed from the DOM.
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    // Hide the overlay 3 seconds after mount. The CSS animation handles
    // fading out starting after 2 seconds.
    const timer = setTimeout(() => setHidden(true), 3000);
    return () => clearTimeout(timer);
  }, []);

  if (hidden) return null;

  return (
    <div className="intro-overlay">
      <div className="logo-wrapper">
        <Image
          src="/logo.jpeg"
          alt="Association World Logo"
          width={300}
          height={300}
          priority
        />
      </div>
      <style jsx>{`
        .intro-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background-color: rgba(0, 0, 0, 0.95);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 9999;
          animation: fadeOut 1s ease forwards;
          /* Delay the fade to allow the logo to be visible for a moment */
          animation-delay: 2s;
        }
        .logo-wrapper {
          position: relative;
          width: 300px;
          height: 300px;
        }
        @keyframes fadeOut {
          to {
            opacity: 0;
            visibility: hidden;
          }
        }
      `}</style>
    </div>
  );
}